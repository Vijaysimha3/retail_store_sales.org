USE retail_store;

INSERT INTO customers (customer_name, email, phone, city)
VALUES
('Rahul Sharma', 'rahul@example.com', '9876543210', 'Bangalore'),
('Priya Verma', 'priya@example.com', '9876543211', 'Chennai'),
('Arjun Reddy', 'arjun@example.com', '9876543212', 'Hyderabad'),
('Sneha Patel', 'sneha@example.com', '9876543213', 'Mumbai');

INSERT INTO products (product_name, category, price, stock)
VALUES
('Laptop', 'Electronics', 55000.00, 10),
('Mouse', 'Electronics', 500.00, 100),
('Keyboard', 'Electronics', 1500.00, 50),
('Office Chair', 'Furniture', 7000.00, 20),
('Notebook', 'Stationery', 50.00, 200);

INSERT INTO orders (customer_id, order_date, status)
VALUES
(1, '2025-01-10', 'Completed'),
(2, '2025-01-11', 'Completed'),
(1, '2025-01-15', 'Completed'),
(3, '2025-01-20', 'Cancelled'),
(4, '2025-01-22', 'Completed');

INSERT INTO order_items (order_id, product_id, quantity, unit_price)
VALUES
(1, 1, 1, 55000.00),
(1, 2, 2, 500.00),
(2, 4, 1, 7000.00),
(2, 5, 10, 50.00),
(3, 3, 1, 1500.00),
(3, 2, 1, 500.00),
(4, 1, 1, 55000.00),
(5, 5, 20, 50.00);
