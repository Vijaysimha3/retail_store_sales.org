# Retail Store Sales SQL Project

This SQL project contains the complete database design and analytics queries for a retail store.  
It includes customer, product, order, and sales data to help analyze revenue and store performance.

## Project Structure
- schema.sql – Table structure
- sample_data.sql – Sample data inserts
- queries.sql – Reporting and insights queries

## How to Run
1. Run schema.sql
2. Run sample_data.sql
3. Run queries.sql

## Features
- Revenue calculation
- Best selling products
- Top customers
- Monthly revenue
- Unsold products
- Order summary view
